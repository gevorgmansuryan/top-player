module.exports = {
	appName: 'Top Player',
	headerHeight: 70,
	height: 470,
	width: 625,
	initialSize: 0.7,
	interactive: {
		padding: 30
	}
};